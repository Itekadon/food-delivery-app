import 'react-native-url-polyfill/auto';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Homescreen from './screens/Homescreen';
import Destinationdetails from './screens/Destinationdetails';
import Accommodation from './screens/Accommodation';
import Restaurants from './screens/Restaurants';
import MapScreen from './screens/Mapscreen';

const Stack = createNativeStackNavigator();

export default function App() {
  const linking = {
    prefixes: ['mzansitravelapp://'],
    config: {
      screens: {
        Home: '',
        Destinationdetails: 'destination/:id',
        Accommodation: 'accommodation/:id',
        Restaurants: 'restaurants',
      },
    },
  };

  return (
    <NavigationContainer linking={linking}>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Homescreen} />
        <Stack.Screen name="Destinationdetails" component={Destinationdetails} />
        <Stack.Screen name="Accommodation" component={Accommodation} />
        <Stack.Screen name="Restaurants" component={Restaurants} />
        <Stack.Screen name="Mapscreen" component={MapScreen} /> 
      </Stack.Navigator>
    </NavigationContainer>
  );
}
