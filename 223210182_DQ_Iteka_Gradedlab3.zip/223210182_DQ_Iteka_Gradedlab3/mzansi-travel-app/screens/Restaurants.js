import React from 'react';
import { View, Text, ScrollView, Image, StyleSheet } from 'react-native';

const restaurants = [
  {
    id: 1,
    name: 'The Test Kitchen',
    image: require('../Images/test.jpg'),
    description: 'A world-renowned fine dining restaurant located in Cape Town, offering innovative cuisine in a chic setting.',
  },
  {
    id: 2,
    name: 'La Colombe',
    image: require('../Images/colombe.jpg'),
    description: 'Situated in Constantia, Cape Town, La Colombe is famous for its refined contemporary cuisine and exceptional wine list.',
  },
  {
    id: 3,
    name: 'Wolfgat',
    image: require('../Images/wolfgat.webp'), 
    description: 'Located in Paternoster, Wolfgat offers a unique dining experience with a focus on foraged ingredients and coastal cuisine.',
  },
  {
    id: 4,
    name: 'The Pot Luck Club',
    image: require('../Images/pot.jpg'), 
    description: 'A trendy spot in Cape Town known for its tapas-style dishes and stunning views of the city.',
  },
  {
    id: 5,
    name: 'FYN',
    image: require('../Images/fyn.jpeg'), 
    description: 'Located in the heart of Cape Town, FYN offers a fusion of Japanese and South African cuisine in an elegant atmosphere.',
  },
  {
    id: 6,
    name: 'Marble',
    image: require('../Images/marble.jpg'), 
    description: 'Situated in Johannesburg, Marble is famous for its live-fire cooking and contemporary urban ambiance.',
  },
  {
    id: 7,
    name: 'DW Eleven-13',
    image: require('../Images/DW-11-13.jpg'), 
    description: 'A Johannesburg-based restaurant offering modern fine dining with a focus on seasonal ingredients and innovative techniques.',
  },
  {
    id: 8,
    name: 'The Greenhouse',
    image: require('../Images/the-greenhouse-johannesburg-1665580207.jpg'), 
    description: 'Located in Constantia, Cape Town, The Greenhouse is known for its imaginative dishes inspired by South African flavors.',
  },
  {
    id: 9,
    name: 'Pier Restaurant',
    image: require('../Images/pier.jpg'), 
    description: 'A contemporary seafood restaurant in V&A Waterfront, Cape Town, with a focus on sustainable seafood and modern techniques.',
  },
  {
    id: 10,
    name: 'Chef’s Warehouse',
    image: require('../Images/chefs.jpg'), 
    description: 'A Cape Town-based restaurant offering a unique tapas-style dining experience with a focus on bold flavors and shared dishes.',
  },
];

const Restaurants = () => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      {restaurants.map((restaurant) => (
        <View key={restaurant.id} style={styles.card}>
          <Image source={restaurant.image} style={styles.image} />
          <Text style={styles.name}>{restaurant.name}</Text>
          <Text style={styles.description}>{restaurant.description}</Text>
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  card: {
    marginBottom: 20,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#fff',
    elevation: 3,
  },
  image: {
    width: '100%',
    height: 200,
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 10,
    paddingHorizontal: 10,
  },
  description: {
    fontSize: 16,
    paddingHorizontal: 10,
    marginBottom: 10,
  },
});

export default Restaurants;
