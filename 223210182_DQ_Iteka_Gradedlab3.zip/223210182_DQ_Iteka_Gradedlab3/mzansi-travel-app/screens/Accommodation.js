import React from 'react';
import { View, Text, ScrollView, Image, StyleSheet } from 'react-native';

const accommodations = [
  {
    id: 1,
    name: 'The Oyster Box',
    image: require('../Images/oysterjpg.jpg'), 
    description: 'A luxurious five-star hotel located in Umhlanga, offering stunning ocean views and top-notch amenities.',
  },
  {
    id: 2,
    name: 'Singita Sabi Sand',
    image: require('../Images/singita.jpg'),
    description: 'An exclusive lodge located in the Sabi Sand Reserve, known for its luxurious accommodations and excellent wildlife viewing.',
  },
  {
    id: 3,
    name: 'Ellerman House',
    image: require('../Images/ellerman.jpg'),
    description: 'A boutique hotel in Cape Town offering exquisite views of the Atlantic Ocean and exceptional service.',
  },
  {
    id: 4,
    name: 'One&Only Cape Town',
    image: require('../Images/one.jpg'), 
    description: 'A luxury resort situated at the Victoria & Alfred Waterfront, known for its elegance and refined atmosphere.',
  },
  {
    id: 5,
    name: 'Twelve Apostles Hotel',
    image: require('../Images/12.jpg'), 
    description: 'A scenic hotel nestled between the Twelve Apostles mountain range and the Atlantic Ocean, offering unparalleled views.',
  },
  {
    id: 6,
    name: 'Le Quartier Français',
    image: require('../Images/quartier.jpg'), 
    description: 'A romantic boutique hotel in Franschhoek, offering luxurious suites and world-class dining experiences.',
  },
  {
    id: 7,
    name: 'Royal Malewane',
    image: require('../Images/royal.jpg'),
    description: 'A prestigious safari lodge in the Thornybush Private Game Reserve, offering a blend of luxury and wilderness.',
  },
  {
    id: 8,
    name: 'Belmond Mount Nelson Hotel',
    image: require('../Images/belmond.jpg'),
    description: 'A historic hotel in Cape Town, offering elegant accommodations and lush gardens.',
  },
  {
    id: 9,
    name: 'Kapama Karula',
    image: require('../Images/kapama.jpg'), 
    description: 'A luxury safari lodge located in the Kapama Private Game Reserve, offering lavish suites and unparalleled wildlife experiences.',
  },
  {
    id: 10,
    name: 'The Silo Hotel',
    image: require('../Images/silojpg.jpg'), 
    description: 'A chic, contemporary hotel located in the V&A Waterfront, offering stylish rooms and panoramic views of Cape Town.',
  },
];

const Accommodation = () => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      {accommodations.map((accommodation) => (
        <View key={accommodation.id} style={styles.card}>
          <Image source={accommodation.image} style={styles.image} />
          <Text style={styles.name}>{accommodation.name}</Text>
          <Text style={styles.description}>{accommodation.description}</Text>
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  card: {
    marginBottom: 20,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#fff',
    elevation: 3,
  },
  image: {
    width: '100%',
    height: 200,
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 10,
    paddingHorizontal: 10,
  },
  description: {
    fontSize: 16,
    paddingHorizontal: 10,
    marginBottom: 10,
  },
});

export default Accommodation;
