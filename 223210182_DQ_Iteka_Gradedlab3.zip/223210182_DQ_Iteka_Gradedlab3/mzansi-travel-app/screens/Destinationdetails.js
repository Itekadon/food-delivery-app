import React from 'react';
import { View, Text, ScrollView, Image, StyleSheet,TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
const destinations = [
  {
    id: 1,
    name: 'Table Mountain',
    image: require('../Images/Table-Mountain.webp'),  
    latitude: -33.9249, 
    longitude: 18.4241,
    description: 'Table Mountain is an iconic landmark overlooking the city of Cape Town, offering stunning views and various hiking trails.',
  },
  {
    id: 2,
    name: 'Kruger National Park',
    image: require('../Images/kruger.jpg'),
    description: 'Kruger National Park is one of Africa’s largest game reserves, home to a variety of wildlife including the Big Five.',
  },
  {
    id: 3,
    name: 'Cape Winelands',
    image: require('../Images/cape-winelands.jpg'),  
    description: 'The Cape Winelands are renowned for their wine estates, offering picturesque vineyards, wine tastings, and gourmet dining experiences.',
  },
  {
    id: 4,
    name: 'Robben Island',
    image: require('../Images/Robben_Island.jpg'),  
    description: 'Robben Island is a UNESCO World Heritage site known for its historical significance, particularly as the location where Nelson Mandela was imprisoned.',
  },
  {
    id: 5,
    name: 'Blyde River Canyon',
    image: require('../Images/Blyde river.jpg'),
    description: 'Blyde River Canyon is one of the largest canyons in the world, offering breathtaking views and various outdoor activities like hiking and boat tours.',
  },
  {
    id: 6,
    name: 'Addo Elephant National Park',
    image: require('../Images/iaddo elephants.jpg'),  
    description: 'Addo Elephant National Park is a diverse wildlife conservation park located close to Port Elizabeth, famous for its elephant population.',
  },
  {
    id: 7,
    name: 'Drakensberg Mountains',
    image: require('../Images/Drakensberg-mountains.webp'),
    description: 'The Drakensberg Mountains are a world heritage site, known for their stunning scenery, hiking trails, and ancient rock art.',
  },
  {
    id: 8,
    name: 'Menlyn Mall',
    image: require('../Images/menyln.jpg'),  
    description: 'Menlyn Mall is one of the largest shopping centers in Africa, located in Pretoria. It offers a wide range of retail stores, restaurants, and entertainment options.',
  },
  {
    id: 9,
    name: 'uShaka Marine World',
    image: require('../Images/ushaka.jpg'),  
    description: 'uShaka Marine World is a popular marine theme park in Durban, featuring an aquarium, water park, and various other attractions.',
  },
  {
    id: 10,
    name: 'Victoria & Alfred Waterfront',
    image: require('../Images/victoria.jpg'), 
    description: 'The Victoria & Alfred Waterfront in Cape Town is a bustling shopping, dining, and entertainment hub located in the city’s harbor.',
  },
];

const Destinationdetails = ({ navigation }) => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      {destinations.map((destination) => (
        <View key={destination.id} style={styles.card}>
          <Image source={destination.image} style={styles.image} />
          <Text style={styles.name}>{destination.name}</Text>
          <TouchableOpacity
          style={styles.mapButton}
          onPress={() => navigation.navigate('MapScreen', {
            latitude: destination.latitude,
            longitude: destination.longitude,
            name: destination.name,
          })}
        ><Icon name="map-outline" size={24} color="#000" /></TouchableOpacity>
          <Text style={styles.description}>{destination.description}</Text>
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  card: {
    marginBottom: 20,
    backgroundColor: '#fff',
    borderRadius: 8,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: 200,
  },
  name: {
    padding: 16,
    fontSize: 18,
    fontWeight: 'bold',
  },
  description: {
    fontSize: 16,
    color: '#666',
    paddingHorizontal: 10,
    paddingBottom: 10,
  },
});

export default Destinationdetails;
