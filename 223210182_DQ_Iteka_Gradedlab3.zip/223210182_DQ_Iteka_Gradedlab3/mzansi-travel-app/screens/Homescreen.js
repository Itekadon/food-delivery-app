import React from 'react';
import { View, Text, Button, Image, StyleSheet } from 'react-native';

const Homescreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.welcomeMessage}>Heita dah, Mzansi! Explore the beauty of South Africa.</Text>
      <Image source={require('../Images/flag.png')} style={styles.flag} />
      <Button
      style = {styles.button}
        title="Explore Destinations"
        onPress={() => navigation.navigate('Destinationdetails')}
      />
      <Text></Text>
      <Button
        style = {styles.button}
        title="Find Accommodation"
        onPress={() => navigation.navigate('Accommodation')}
      />
      <Text></Text>
      <Button
      style = {styles.button}
        title="Discover Restaurants"
        onPress={() => navigation.navigate('Restaurants')}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  welcomeMessage: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  flag: {
    width: 200,
    height: 100,
    marginBottom: 30,
    borderRadius:9
  },
  button:{
    width:300,
    borderRadius:10
  }
});

export default Homescreen;
